package com.example.hobbie.model.entities.enums;

public enum GenderEnum {
    MALE, FEMALE, OTHER;
}
