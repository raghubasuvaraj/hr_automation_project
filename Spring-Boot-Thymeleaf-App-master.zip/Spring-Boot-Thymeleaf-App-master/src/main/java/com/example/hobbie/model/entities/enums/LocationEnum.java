package com.example.hobbie.model.entities.enums;

public enum LocationEnum {
    ZURICH, OTHER;
}
