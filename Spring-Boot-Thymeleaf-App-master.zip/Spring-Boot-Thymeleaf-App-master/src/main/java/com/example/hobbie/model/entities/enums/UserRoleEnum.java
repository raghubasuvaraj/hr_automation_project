package com.example.hobbie.model.entities.enums;

public enum UserRoleEnum {
    ADMIN, USER, BUSINESS_USER;
}
