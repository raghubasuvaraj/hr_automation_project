package com.example.hobbie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HobbieApplicationTests {
    @Test
    void contextLoads() {
    }
}
